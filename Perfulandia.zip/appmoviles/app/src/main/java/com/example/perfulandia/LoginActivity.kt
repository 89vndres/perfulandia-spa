// Archivo: LoginActivity.kt
package com.ejemplo.perfulandia

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val etEmail = findViewById<EditText>(R.id.etEmail)
        val etPass = findViewById<EditText>(R.id.etPass)
        val btnLogin = findViewById<Button>(R.id.btnLogin)
        val progressBar = findViewById<ProgressBar>(R.id.progressBar)

        btnLogin.setOnClickListener {
            val email = etEmail.text.toString()
            val pass = etPass.text.toString()

            // Validación de formulario (Requisito 2)
            if (email.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, "Email y contraseña son requeridos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Gestión de Estado (Requisito 4)
            progressBar.visibility = View.VISIBLE
            btnLogin.isEnabled = false

            lifecycleScope.launch {
                try {
                    // Consumo de API Real (Requisito 8)
                    val response = RetrofitClient.instance.login(LoginRequest(email, pass))

                    // Guardar Token (Almacenamiento Local)
                    guardarToken(response.authToken)

                    // Navegación (Requisito 3)
                    val intent = Intent(this@LoginActivity, MainActivity::class.java)
                    startActivity(intent)
                    finish() // Termina LoginActivity

                } catch (e: Exception) {
                    // Gestión de Estado (Error)
                    progressBar.visibility = View.GONE
                    btnLogin.isEnabled = true
                    Toast.makeText(this, "Error de login: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun guardarToken(token: String) {
        // SharedPreferences es otra forma de almacenamiento local (perfecto para el token)
        val prefs = getSharedPreferences("PERFULANDIA_PREFS", Context.MODE_PRIVATE)
        prefs.edit().putString("AUTH_TOKEN", token).apply()
    }
}
