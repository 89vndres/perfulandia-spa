// Archivo: BaseDeDatos.kt
package com.ejemplo.perfulandia

import android.content.Context
import androidx.room.*

// 1. La Entidad (El producto en el carrito)
@Entity(tableName = "carrito_tabla")
data class ProductoCarrito(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val nombre: String,
    val precio: Double,
    val cantidad: Int
)

// 2. El DAO (Data Access Object - Consultas)
@Dao
interface CarritoDao {
    @Query("SELECT * FROM carrito_tabla")
    suspend fun obtenerCarrito(): List<ProductoCarrito>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun agregarProducto(producto: ProductoCarrito)

    @Delete
    suspend fun eliminarProducto(producto: ProductoCarrito)

    @Query("DELETE FROM carrito_tabla")
    suspend fun vaciarCarrito()
}

// 3. La Base de Datos
@Database(entities = [ProductoCarrito::class], version = 1)
abstract class AppDatabase : RoomDatabase() {
    abstract fun carritoDao(): CarritoDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "perfulandia_db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
