
package com.ejemplo.perfulandia

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST

// --- Modelos de datos para la API ---
// (Lo que envías al login)
data class LoginRequest(
    val email: String,
    val pass: String // La API de Xano puede usar 'pass' o 'password'
)

// (Lo que recibes del login)
data class LoginResponse(
    val authToken: String
)

// --- Interfaz de Retrofit ---
interface ApiService {
    @POST("/api:Rfm_61dW/auth/login")
    suspend fun login(@Body request: LoginRequest): LoginResponse

    // Aquí puedes añadir /auth/me, /auth/signup, etc.
}

// --- Objeto Singleton para usar Retrofit ---
object RetrofitClient {
    private const val BASE_URL = "[https://x8ki-letl-twmt.n7.xano.io](https://x8ki-letl-twmt.n7.xano.io)"

    val instance: ApiService by lazy {
        val retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
        retrofit.create(ApiService::class.java)
    }
}
