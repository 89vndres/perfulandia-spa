// Archivo: Perfume.kt
package com.ejemplo.perfulandia

data class Perfume(
    val id: Int,
    val nombre: String,
    val marca: String,
    val precio: Double,
    val descripcion: String
)
