
package com.ejemplo.perfulandia

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.lifecycle.lifecycleScope
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    // Vistas
    private lateinit var tvStatus: TextView
    private lateinit var btnComprar: Button
    private lateinit var btnVerCarrito: Button
    private lateinit var btnUbicacion: Button
    private lateinit var btnTomarFoto: Button
    private lateinit var ivFotoPerfil: ImageView

    // Base de datos y Ubicación
    private lateinit var db: AppDatabase
    private lateinit var fusedLocationClient: FusedLocationProviderClient

    // --- Launcher para la Cámara (Recurso Nativo 2) ---
    private val tomarFotoLauncher = registerForActivityResult(
        ActivityResultContracts.TakePicturePreview()
    ) { bitmap: Bitmap? ->
        if (bitmap != null) {
            ivFotoPerfil.setImageBitmap(bitmap)
            // Aquí guardarías el bitmap en almacenamiento local (Requisito 11)
            Toast.makeText(this, "Foto capturada y guardada localmente", Toast.LENGTH_SHORT).show()
        }
    }

    // --- Launcher para permisos ---
    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        if (isGranted) {
            // El usuario dio permiso
            if (solicitando == "CAMARA") {
                abrirCamara()
            } else if (solicitando == "UBICACION") {
                obtenerUbicacion()
            }
        } else {
            Toast.makeText(this, "Permiso denegado", Toast.LENGTH_SHORT).show()
        }
    }
    private var solicitando = "" // Para saber qué permiso pedimos

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Inicializar componentes
        db = AppDatabase.getDatabase(this)
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        // Referencias a vistas
        tvStatus = findViewById(R.id.tvStatus)
        btnComprar = findViewById(R.id.btnComprar)
        btnVerCarrito = findViewById(R.id.btnVerCarrito)
        btnUbicacion = findViewById(R.id.btnUbicacion)
        btnTomarFoto = findViewById(R.id.btnTomarFoto)
        ivFotoPerfil = findViewById(R.id.ivFotoPerfil)

        // LÓGICA DE CARRITO (Requisito 5 - Persistencia)
        btnComprar.setOnClickListener {
            val perfumeNuevo = ProductoCarrito(nombre = "Chanel No 5", precio = 120.0, cantidad = 1)
            lifecycleScope.launch {
                db.carritoDao().agregarProducto(perfumeNuevo)
                Toast.makeText(applicationContext, "Perfume guardado en carrito (Room)", Toast.LENGTH_SHORT).show()
            }
        }

        btnVerCarrito.setOnClickListener {
            lifecycleScope.launch {
                val lista = db.carritoDao().obtenerCarrito()
                val total = lista.sumOf { it.precio }
                tvStatus.text = "Carrito: ${lista.size} perfumes. Total: $$total"
            }
        }

        // RECURSO NATIVO 1 (GPS)
        btnUbicacion.setOnClickListener {
            solicitando = "UBICACION"
            pedirPermiso(Manifest.permission.ACCESS_FINE_LOCATION)
        }

        // RECURSO NATIVO 2 (Cámara)
        btnTomarFoto.setOnClickListener {
            solicitando = "CAMARA"
            pedirPermiso(Manifest.permission.CAMERA)
        }
    }

    private fun pedirPermiso(permiso: String) {
        when {
            ActivityCompat.checkSelfPermission(this, permiso) == PackageManager.PERMISSION_GRANTED -> {
                // Permiso ya concedido
                if (permiso == Manifest.permission.CAMERA) abrirCamara()
                if (permiso == Manifest.permission.ACCESS_FINE_LOCATION) obtenerUbicacion()
            }
            else -> {
                // Pedir permiso
                requestPermissionLauncher.launch(permiso)
            }
        }
    }

    private fun abrirCamara() {
        tomarFotoLauncher.launch(null) // Lanza la cámara
    }

    private fun obtenerUbicacion() {

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return
        }

        fusedLocationClient.lastLocation
            .addOnSuccessListener { location ->
                if (location != null) {
                    tvStatus.text = "Tu ubicación: Lat ${location.latitude}, Long ${location.longitude}"
                    Toast.makeText(this, "Ubicación obtenida (GPS)", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "No se pudo obtener ubicación", Toast.LENGTH_SHORT).show()
                }
            }
    }
}
